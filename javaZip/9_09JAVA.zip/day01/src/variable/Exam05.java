package variable;

public class Exam05 {

	public static void main(String[] args) {
		//����
//		int a = 10;
//		a = 20;
//		a = 100;
		
		//���
//		final int b = 50;
//		int maxValue = 50;
		
//		final double PI = 3.14;
//		final int MAX_SIZE = 10;
	}

}
