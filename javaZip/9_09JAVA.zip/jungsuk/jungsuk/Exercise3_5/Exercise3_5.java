package Exercise3_5;

public class Exercise3_5 {
public static void main(String[] args) {
	int num = 333;
	System.out.println((int)(Math.round(num)/100 * 100.0 + 1));
}
}
