package Exercise7_26;

public class Exercise7_26 {
public static void main(String[] args) {
	Outer.Inner inner = new Outer.Inner(); // Inner�� static �޼���
	
	System.out.println(inner.iv);
	
}
}
