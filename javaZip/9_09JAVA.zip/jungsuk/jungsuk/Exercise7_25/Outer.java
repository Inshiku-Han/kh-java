package Exercise7_25;

public class Outer {
	public class Inner{
		int iv = 100;
	}
}
