package day08;

public class PrinterTest {
public static void main(String[] args) {
	LazerPrinter p = new LazerPrinter();
	p.print();
}
}
