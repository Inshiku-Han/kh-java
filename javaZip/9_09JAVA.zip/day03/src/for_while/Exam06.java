package for_while;

public class Exam06 {

	public static void main(String[] args) {
		// ���� for��

//		for (int j = 0; j < 5; j++) {
//
//			for (int i = 0; i < 5; i++) {
//				System.out.print("*");
//			}
//			System.out.println();
//		}
		
		// 1  2  3
		// 4  5  6
		// 7  8  9
//		int num = 0;
//		for(int i = 0 ; i < 3 ; i++) {
//			for(int j = 0 ; j < 3 ; j++) {
//				System.out.print(++num + "\t");
//			}
//			System.out.println();
//		}
		
		//������ �����
		
//		for(int i = 1 ; i < 10 ; i++) {
//			for(int j = 2 ; j < 10 ; j++) {
//				System.out.print(j + " x " + i + " = " + i*j + "\t");
//			}
//			System.out.println();
//		}
		
// ���ѷ��� : while(true){}     for(;;){}
		
	}

}
