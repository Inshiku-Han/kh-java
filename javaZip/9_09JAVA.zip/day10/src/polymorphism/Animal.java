package polymorphism;

public interface Animal {
	
public void sound();
}
