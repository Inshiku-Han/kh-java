package methodPractice;

public class hello {
	String str;

	public hello() {
		super();
	}

	public hello(String str) {
		super();
		this.str = str;
	}

	@Override
	public String toString() {
		return "hello [str=" + str + "]";
	}
	
	
}
