package julyFifteenth;

public class CalculateActive {
public static void main(String[] args) {
	Calculate cal = new Calculate(10,20,15);
	cal.triArea();
	cal.rectArea();
	cal.rectPeri();
	cal.cirArea();
	cal.cirCir();
}
}
