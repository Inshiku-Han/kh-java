package variablePractice;

public class variablePractice4 {

	public static void main(String[] args) {
		int a = 10;
		int b = 20;
		int c = 0;
		c = b;
		b = a;
		a = c;
		System.out.println(a);
		System.out.println(b);
	}

}
