package fieldClass;

public class Member2Test {

	public static void main(String[] args) {
		Member2 user1 = new Member2("ȫ�浿","hong");
		Member2 user2 = new Member2("���ڹ�","java");
		
		
		user1.display();
		System.out.println();
		user2.display();
		
	}

}
