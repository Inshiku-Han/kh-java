package haninsik01;

public class MemberTest {
public static void main(String[] args) {
	Member member = new Member("���ν�", "insik", 1234, 26);
	member.display();
}
}
