package haninsik01;

public class MemberService {

	public static void main(String[] args) {
Member member = new Member("java",1234);
member.login();
	}

}
