package variable;

public class Exam06 {

	public static void main(String[] args) {
		System.out.println("a" + "\t" + "b");
		System.out.println("a\tb");
		System.out.println("\"�ȳ��ϼ���\"");
	}

}
