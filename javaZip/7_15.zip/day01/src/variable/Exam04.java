package variable;

public class Exam04 {
	public static void main(String[] args) {
//		char ch1 = 'A';
//		char ch2 = 65;//�ƽ�Ű �ڵ�
//		System.out.println("ch1 = " + ch1);
//		System.out.println("ch2 = " + ch2);
		
		boolean b1 = true;
		boolean b2 = false;
		
		System.out.println("b1 = " + b1);
		System.out.println("b2 = " + b2);
		System.out.println(10 > 5);
		
		int num1 = 10;
		int num2 = 20;
		
		System.out.println(num1 < num2);
	}

}
