package arrayListInherit;

public class Student1 extends Sungjuk{
	
}

