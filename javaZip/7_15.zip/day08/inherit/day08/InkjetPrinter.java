package day08;

public class InkjetPrinter extends Printer{
	int inkjet;
}
