package methodPractice;

public class helloTest {
	public static void main(String[] args) {
		hello hello = new hello("�ȳ��ϼ���");
		System.out.println(hello.toString());
	}
}
