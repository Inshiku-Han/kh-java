package variablePractice;

public class variablePractice2 {

	public static void main(String[] args) {
		int a = 1;
		double b = 2.2;
		b = a;
		
		System.out.println("a = " + a); // a = 1
		System.out.println("b = " + b); // b = 1.0
		
	}

}
