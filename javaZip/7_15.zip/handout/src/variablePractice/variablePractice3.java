package variablePractice;

public class variablePractice3 {

	public static void main(String[] args) {
		int num1 = 0;
		double num2 = 10.7;
		
		num1 = (int)num2;
		System.out.println(num1);
		
	}

}
