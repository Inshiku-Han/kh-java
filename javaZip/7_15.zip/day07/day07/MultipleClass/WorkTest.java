package MultipleClass;

public class WorkTest {

	public static void main(String[] args) {
		Worker w = new Worker();
		w.setWorkerInfo("�ڹ�", 20, "���", "KH", "java", 2000000);
		w.displayWorkerInfo();
	}

}
