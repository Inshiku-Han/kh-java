package if_switch;

public class Exam14 {

	public static void main(String[] args) {
		int a = 10;
		int b = 4;
		System.out.println("result = " + a / (double)b);
	}

}
