package Exercise6_22;

public class Exercise6_22 {
	
//	public static boolean isNumber(String str) {
//		if(str == null || str.equals("")) 
//			return false;
//		for() {
		
		
	
	
public static void main(String[] args) {
	String str = "123";
//	System.out.println(str + "�� �����Դϱ�?" + isNumber(str));
	
	str = "1234o";
//	System.out.println(str + "�� �����Դϱ�?" + isNumber(str));
}
}
