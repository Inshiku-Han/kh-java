package Exercise7_26;

public class Outer {
	static class Inner{
		int iv = 200;
	}
}
