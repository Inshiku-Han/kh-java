package Exercise6_24;

public class Exercise6_24 {

	
}
