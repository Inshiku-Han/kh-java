package Exercise3_4;

public class Exercise3_4 {
	public static void main(String[] args) {
		int num = 456;
System.out.println((int)(Math.round(num)/100 * 100.0));		
	}
	
}
