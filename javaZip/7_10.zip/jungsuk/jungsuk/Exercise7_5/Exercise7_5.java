package Exercise7_5;

public class Exercise7_5 {

	public static void main(String[] args) {
		Tv t = new Tv();
		System.out.println(t.toString());
}
}
