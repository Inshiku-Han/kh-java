package day08;

public class Tire {
	public void run() {
		System.out.println("�Ϲ� Ÿ�̾�");
	}
}
