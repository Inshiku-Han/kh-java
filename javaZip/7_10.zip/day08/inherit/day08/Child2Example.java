package day08;

public class Child2Example {
public static void main(String[] args) {
	Child2 c = new Child2();
	
}
}
