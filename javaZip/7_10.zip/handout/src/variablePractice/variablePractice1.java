package variablePractice;

public class variablePractice1 {

	public static void main(String[] args) {
		int a = 10;
		int b = 20;
		int c = 30;
		
		System.out.println(a + b + c); // 60
	}

}
