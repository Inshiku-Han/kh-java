package printPractice;

public class printPractice {
public static void main(String[] args) {
	System.out.println("a" + "b"); // ab
	System.out.println(1*3+2); // 5
	System.out.println("abc" + 1 + "ed"); // abc1ed
	System.out.println(3 + 5 + "abc" + 1); // 8abc1
	System.out.println(1 + "2" + 3); // 123
	
	int a = 10;
	int b = 20;
	System.out.println("a + b = " + (a+b)); // a + b = 30
	System.out.println("a + b = " + a + b); // a + b = 1020
	System.out.println("a + b = "); // a + b =
	System.out.println(a + b); // 30
	int c = b - a;
	System.out.println(a + " + " + b + " = " + c); // 10 + 20 = 10
	
}
}
