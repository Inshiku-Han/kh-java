package ifPractice;

import java.util.Scanner;

public class switchPracitce1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("�Է� : ");
		String str = sc.next();
		
		
		switch(str){
		case "��" : System.out.println("�����Դϴ�");
		break;
		case "��" : System.out.println("�����Դϴ�");
		break;
		default : System.out.println("�ٽ�");
		
		}
		
		
		
		
		
		
		sc.close();
	}

}
