package fieldClass;

public class MemberTest {
public static void main(String[] args) {
	Member m = new Member();
	m.setInfor("�ڹ�", "java", 123);
	
	m.display();
}
}
