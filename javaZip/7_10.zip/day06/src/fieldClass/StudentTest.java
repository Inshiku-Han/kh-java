package fieldClass;

public class StudentTest {
public static void main(String[] args) {
	Student s = new Student();
	s.name = "���ν�";
	s.age = 26;
	s.adress = "���";
	s.schoolNumber = 1403218;
	s.phoneNumber = 123456;
	s.display();
}
}
