package fieldClass;

public class PersonTest {

	public static void main(String[] args) {
		Person p = new Person();
		
		p.setName("���ν�");
		p.setAge(26);
		p.display(); 		
	}

}
