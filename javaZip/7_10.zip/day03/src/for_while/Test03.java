package for_while;

public class Test03 {

	public static void main(String[] args) {
		int a =5;
		
		if(a > 5) {
			System.out.println("A");
		}else if(a  == 5) {
			System.out.println("B");
		}else if(a <= 5) {
			System.out.println("C");
		}
	}

}
