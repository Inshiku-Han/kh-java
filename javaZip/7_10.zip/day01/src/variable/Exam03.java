package variable;

public class Exam03 {
	public static void main(String[] args) {
//		int num1, num2;
//		num1 = 0;
//		num2 = 1;
		
//		long x = 10L;
		
//		num1 = 1.1;
//		double num3 = 1.5;
//		float num4 = 1.5F;
//		num3 = 10;
		
//		����
//		char val1 = 'A';
//		��, ����
//		boolean flag = true;
//		boolean flag1 = false;
//		���ڿ�
//		String str = "asdf";
		
		
	}
}
