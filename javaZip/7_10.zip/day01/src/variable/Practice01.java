package variable;

public class Practice01 {
	public static void main(String[] args) {
		int a = 10;
		int b = 20;
		int c = 30;
		
		System.out.println("a = " + a);
		System.out.println("b = " + b);
		System.out.println("c = " + c);
		int d = (a+b+c);
		System.out.println("a + b + c = " + d);
		
		int num1;
		double num2 = 10.7;
		
		num1 = (int) num2;
		System.out.println(num1);
		
	}

}
